let lovefunc = (flower1, flower2) => {
  return flower1 % 2 !== flower2 % 2;
}


console.log(lovefunc(613, 309));
//console.log(((613), 2), 309 / 2);
//console.log(lovefunc());
